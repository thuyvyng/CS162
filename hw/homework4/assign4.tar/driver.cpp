//name: thuyvy nguyen
//assignment: 4
//description: bees & ant
//date: 29 may 2018

#include <iostream>
#include <vector>
#include "bee.h"
#include "ant.h"
#include "insect.h"
#include "game.h"


using namespace std;

int main(){

	Game game;

	cout << endl << "Welcome to Ants vs. Some Bees!" << endl;
	game.letsplaygame();

	return 0;
}
