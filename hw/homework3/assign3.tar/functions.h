#include <iostream>
#include <string>

using namespace std;

struct more_business{
	string size;
	int rent;

};

class RandProp{
	public:
		string property_location();
		int property_mortage();
		int property_value_h();
		int property_a();
		int property_b();
		string property_size();
};
