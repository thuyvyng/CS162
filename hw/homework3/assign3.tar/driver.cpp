//name: thuyvy nguyen
//assignment: 3
//date: 13 5 18

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cmath>

#include "properties.h"
#include "functions.h"
#include "players.h"

using namespace std;


//******************************************************************
int main(){
	srand(time(NULL));

	cout << "Welcome to Real Estate Game!" << endl << endl;

        LetPlayGame();

	return 0;
}
